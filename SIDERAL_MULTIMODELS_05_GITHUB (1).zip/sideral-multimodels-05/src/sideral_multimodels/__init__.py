"""SIDERAL MULTIMODELS 0.5 — protótipo de grade compartilhada e consenso."""
__version__ = "0.1.0"
